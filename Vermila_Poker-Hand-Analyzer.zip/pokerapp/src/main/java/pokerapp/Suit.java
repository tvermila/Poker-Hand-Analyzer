/**
 * @author Tomas Vermil�
 */

package pokerapp;

public enum Suit {
	CLUBS, DIAMONDS, HEARTS, SPADES
}
